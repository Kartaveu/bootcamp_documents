import { Component, OnInit } from '@angular/core';
import { Order } from '../order';
import { OrderService } from '../order.service';

@Component({
  selector: 'app-submitOrder',
  templateUrl: './submitOrder.component.html',
  styleUrls: ['./submitOrder.component.css']
})
export class SubmitorderComponent implements OnInit {

  order:Order=new Order();
  msg:String;
  errorMsg:String;
  constructor(private orderService:OrderService) { }

  ngOnInit(): void {
  }

  submitOrder(){
    console.log("Inside SubmitOrder");
    this.orderService.submitOrder(this.order).subscribe((data)=>{
      console.log("data",data);
      this.msg=data;
      this.errorMsg=undefined;
      this.order=new Order()},
      error=>{this.errorMsg=JSON.parse(error.error).message;
      console.log(error.error);
      this.msg=undefined});

      

}
}