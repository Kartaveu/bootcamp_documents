package com.capgemini.bookstore.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;
//import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


//import org.hibernate.annotations.DynamicInsert;
//import org.hibernate.annotations.DynamicUpdate;



@Entity
@Table(name="Order_Table")
//@DynamicUpdate(true)
//@DynamicInsert(true)
//@SequenceGenerator(name="orderID_gen",initialValue = 1,allocationSize = 50)
public class Order {
	
	//@GeneratedValue(generator="orderId_gen",strategy = GenerationType.SEQUENCE)
	@Id
	@Column(name="order_id")
	//@NotNull
	//@Positive
	private Integer orderId;
	
	@Column(name="customerId")
	//@NotNull
	//@Positive
	private Integer customerId;

	@Column(name="customername")
	//@NotEmpty(message="Customername not be nulled")
	//@Positive
	private  String customerName;

	@Column(name="bookId")
	//@NotNull
	//@Positive
	private Integer bookId;

	@Column(name="Amount")
	//@NotEmpty(message="must not be null")
	//@Positive
	private Float amount;
	
	@Column(name="Orderaddress")
	//@NotEmpty(message="must not be null")
	private String address;

	
	

	public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Integer getBookId() {
		return bookId;
	}

	public void setBookId(Integer bookId) {
		this.bookId = bookId;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}


	public Order(int orderId, int customerId, String customerName,int bookId,Float amount,String address) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.customerName = customerName;
		this.bookId = bookId;
		this.amount = amount;
		this.address = address;
		
	}
	
	public Order() {
		super();
	}
	
	@Override
	public String toString() {
		return "Order[orderId=" + orderId +", customerId=" + customerId +", customerame=" + customerName +", bookId=" + bookId +", amount=" + amount +", address=" + address +"]";
	}
}
