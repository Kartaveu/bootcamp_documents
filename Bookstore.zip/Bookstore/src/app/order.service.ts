import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  constructor(private http:HttpClient) { }

  public showallorder():Observable<any>{
    console.log("Am inside service");
    return this.http.get("http://localhost:7577/viewallorder");
  }


  public submitOrder(order:Order):Observable<any>{
    return this.http.post("http://localhost:7577/submitorder",order,{responseType:'text'});
  }
}
