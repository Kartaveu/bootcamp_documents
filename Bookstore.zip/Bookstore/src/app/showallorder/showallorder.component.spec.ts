import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowallorderComponent } from './showallorder.component';

describe('ShowallorderComponent', () => {
  let component: ShowallorderComponent;
  let fixture: ComponentFixture<ShowallorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowallorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowallorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
