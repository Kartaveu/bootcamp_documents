import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ShowallorderComponent } from './showallorder/showallorder.component';
import { SubmitorderComponent } from './submitOrder/submitOrder.component';

const routes: Routes = [
  {path:'showallorder', component:ShowallorderComponent},
  {path:'submitorder', component:SubmitorderComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
