import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmitorderComponent } from './submitOrder.component';

describe('SubmitOrderComponent', () => {
  let component: SubmitorderComponent;
  let fixture: ComponentFixture<SubmitorderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubmitorderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmitorderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
