export class Order {
    orderId:number;
    customerId:number;
    customerName:string;
    bookId:number;
    amount:number;
    address:string;
}
